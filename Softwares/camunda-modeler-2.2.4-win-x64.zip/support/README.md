# Support Scripts

Use the script `register_fileassoc.bat` in this directory
to register the Camunda Modeler as the default editor
for BPMN, CMMN and DMN files.